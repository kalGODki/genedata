﻿using System;
using System.Collections.Generic;
using System.IO;

namespace GeneticsProject
{
    public struct GeneticData
    {
        public string Name; // Название белка
        public string Organism; // Название организма
        public string Formula; // Формула аминокислот
    }

    class Program
    {
        static List<GeneticData> data = new List<GeneticData>();

        static void Main(string[] args)
        {
            // чтение данных из файлов и выполнение команд
            for (int i = 0; i < 3; i++)
            {
                string sequenceFile = $"sequences.{i}.txt";
                string commandFile = $"commands.{i}.txt";
                string outputFile = $"genedata.{i}.txt";

                ReadGeneticData(sequenceFile);
                ReadHandleCommands(commandFile, outputFile); // выполнение команд и запись
            }
        }

        static void ReadGeneticData(string filename)
        {
            using (StreamReader reader = new StreamReader(filename))
            {
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] fragments = line.Split('\t');
                    GeneticData protein;
                    protein.Name = fragments[0];
                    protein.Organism = fragments[1];
                    protein.Formula = Decoding(fragments[2]);
                    data.Add(protein);
                }
            }
        }
        // чтение команд и выполнение операций
        static void ReadHandleCommands(string filename, string outputFile)
        {
            using (StreamReader reader = new StreamReader(filename))
            using (StreamWriter writer = new StreamWriter(outputFile))
            {
                writer.WriteLine("Yurchik Vladislav");
                writer.WriteLine("Genetic searching");
                writer.WriteLine(new string('-', 74));

                int counter = 0;
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    counter++;
                    string[] command = line.Split('\t');
                    string operation = command[0];
                    writer.WriteLine($"{counter.ToString("D3")}   {operation}   {string.Join("   ", command[1..])}");

                    switch (operation)
                    {
                        case "search":
                            Search(command[1], writer);
                            break;
                        case "diff":
                            Diff(command[1], command[2], writer);
                            break;
                        case "mode":
                            Mode(command[1], writer);
                            break;
                        default:
                            writer.WriteLine("UNKNOWN OPERATION");
                            break;
                    }
                    writer.WriteLine(new string('-', 74));
                }
            }
        }

        // операция поиска последовательности аминокислот
        static void Search(string aminoAcid, StreamWriter writer)
        {
            bool found = false; // найдена ли последовательность
            writer.WriteLine("organism        protein");
            string decoded = Decoding(aminoAcid);
            foreach (GeneticData item in data) // перебор всех белков в коллекции данных
            {
                if (item.Formula.Contains(decoded)) // содержит ли белок указанную последовательность
                {
                    writer.WriteLine($"{item.Organism}    {item.Name}"); // выводит организм и название белка
                    found = true;
                }
            }
            if (!found)
            {
                writer.WriteLine("NOT FOUND");
            }
        }// операция сравнения двух белков
        // сколько аминокислот необходимо заменить, чтобы генетически превратить белок 1 в белок 2.
        static void Diff(string protein1, string protein2, StreamWriter writer)
        {
            string formula1 = GetFormula(protein1);
            string formula2 = GetFormula(protein2);

            writer.WriteLine("amino-acids difference:");
            if (formula1 == null || formula2 == null)
            {
                int differences = Math.Max(formula1.Length, formula2.Length); // инициализация кол-ва различий длиной самого длинного белка
                for (int i = 0; i < Math.Min(formula1.Length, formula2.Length); i++) // перебор аминокислот до длины самого короткого белка
                {
                    if (formula1[i] == formula2[i]) // аминокислоты одинаковы
                    {
                        differences--;
                    }
                }

                writer.WriteLine($"{differences}");
            }
            else
            {
                writer.Write("MISSING:");
                if (formula1 == null) writer.Write($" {protein1}");
                if (formula2 == null) writer.Write($" {protein2}");
                writer.WriteLine();
                return;
            }
        }

        // операция определения наиболее часто встречающейся аминокислоты
        static void Mode(string protein, StreamWriter writer)
        {
            string formula = GetFormula(protein); // последовательность аминокислот для указанного белка
            writer.WriteLine("amino-acid occurs:");
            if (formula == null)
            {
                writer.WriteLine($"MISSING: {protein}");
                return;
            }

            var frequency = new Dictionary<char, int>(); // словарь для подсчета частоты встречаемости
            foreach (char c in formula) // перебор каждой аминокислоты в последовательности
            {
                if (frequency.ContainsKey(c))
                    frequency[c]++;
                else
                    frequency[c] = 1;
            }

            char mostFrequent = ' ';
            int maxCount = 0;
            foreach (var kvp in frequency) // находим самую часто встечающуюся аминокислоту и кол-во
            {
                if (kvp.Value > maxCount||kvp.Value == maxCount && kvp.Key < mostFrequent)
                {
                    mostFrequent = kvp.Key;
                    maxCount = kvp.Value;
                }
            }

            writer.WriteLine($"{mostFrequent}          {maxCount}");
        }

        // получение формулы белка по имени
        static string GetFormula(string proteinName)
        {
            foreach (GeneticData item in data)
            {
                if (item.Name.Equals(proteinName))
                {
                    return item.Formula;
                }
            }
            return null;
        }

        static string Encoding(string formula)
        {
            string encoded = string.Empty;
            for (int i = 0; i < formula.Length; i++)
            {
                char ch = formula[i];
                int count = 1;
                while (i < formula.Length - 1 && formula[i + 1] == ch)
                {
                    count++;
                    i++;
                }
                if (count > 2) encoded += count + ch.ToString();
                else encoded += new string(ch, count);
            }
            return encoded;
        }

        static string Decoding(string formula)
        {
            string decoded = string.Empty;
            for (int i = 0; i < formula.Length; i++)
            {
                if (char.IsDigit(formula[i]))
                {
                    char letter = formula[i + 1];
                    int count = formula[i] - '0';
                    decoded += new string(letter, count);
                    i++;
                }
                else
                {
                    decoded += formula[i];
                }
            }
            return decoded;
        }
    }
}